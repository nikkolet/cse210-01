from game.director import Director

director = Director()
director.start_game()